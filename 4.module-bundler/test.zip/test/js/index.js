import Greet from "./Greet.js";
import getRandomString from "./helpers.js";

console.log(getRandomString());

window.zever = getRandomString;
